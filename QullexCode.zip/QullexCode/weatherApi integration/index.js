const express = require("express");
const bodyParser = require("body-parser");
const request = require("request");
const app = express();

const apiKey = "e9961a00c77b4263811212400212812";

app.use(express.static("public"));
app.use(bodyParser.urlencoded({ extended: true }));
app.set("view engine", "ejs");

app.get("/", function (req, res) {
  res.render("index", { weather: null, error: null });
});

app.post("/", function (req, res) {
  let city = req.body.city;
  let url = `http://api.weatherapi.com/v1/current.json?key=${apiKey}&q=${city}`;
  console.log(url);
  request(url, function (err, response, body) {
    console.log(JSON.parse(body));
    if (err) {
      console.log(err);
      res.render("index", { weather: null, error: "Error, please try again" });
    } else {
      let weather = JSON.parse(body);
      console.log(weather);
      if (weather.location == undefined) {
        res.render("index", {
          weather: null,
          error: "Error, please try again",
        });
      } else {
        let weatherText = `It's ${weather.location.name} degrees in ${weather.current.temp_c}!`;
        res.render("index", { weather: weatherText, error: null });
      }
    }
  });
});

app.listen(3001, function () {
  console.log("Example app listening on port 3000!");
});
